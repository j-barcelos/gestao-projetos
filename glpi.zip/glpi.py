# -*- coding: utf-8 -*-
"""
gerar_documento.py
Gera o documento "Inventário e Patrimônio" (projeto GLPI 11) em formato ABNT.
Requisitos: pip install python-docx
Estrutura esperada:
  ./gerar_documento.py
  ./assets/figura1.png ... figura6.png  (prints dos passos no GLPI 11)
"""

import os
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSETS_DIR = os.path.join(BASE_DIR, "assets")

PRETO = RGBColor(0, 0, 0)


# ---------------------------------------------------------------- utilidades
def configurar_pagina(doc):
    """Margens ABNT: 3 cm superior/esquerda, 2 cm inferior/direita."""
    for secao in doc.sections:
        secao.top_margin = Cm(3)
        secao.left_margin = Cm(3)
        secao.bottom_margin = Cm(2)
        secao.right_margin = Cm(2)


def definir_estilos(doc):
    """Fonte Times New Roman 12, preto, em todos os estilos relevantes."""
    nomes = ["Normal", "Title", "Heading 1", "Heading 2", "Caption"]
    for nome in nomes:
        try:
            estilo = doc.styles[nome]
        except KeyError:
            continue
        estilo.font.name = "Times New Roman"
        estilo.font.size = Pt(12)
        estilo.font.color.rgb = PRETO
        # garante a fonte também para textos com acentuação (east asian)
        rpr = estilo.element.get_or_add_rPr()
        rfonts = rpr.find(qn("w:rFonts"))
        if rfonts is None:
            rfonts = OxmlElement("w:rFonts")
            rpr.append(rfonts)
        rfonts.set(qn("w:ascii"), "Times New Roman")
        rfonts.set(qn("w:hAnsi"), "Times New Roman")

    normal = doc.styles["Normal"]
    normal.paragraph_format.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE
    normal.paragraph_format.space_after = Pt(0)
    normal.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY


def paragrafo(doc, texto, negrito=False, tamanho=12, alinhamento=WD_ALIGN_PARAGRAPH.JUSTIFY,
              espacamento=1.5, recuo_primeira=None, antes=0, depois=0):
    p = doc.add_paragraph()
    p.alignment = alinhamento
    pf = p.paragraph_format
    pf.line_spacing = espacamento
    pf.space_before = Pt(antes)
    pf.space_after = Pt(depois)
    if recuo_primeira:
        pf.first_line_indent = Cm(recuo_primeira)
    run = p.add_run(texto)
    run.font.name = "Times New Roman"
    run.font.size = Pt(tamanho)
    run.font.color.rgb = PRETO
    run.bold = negrito
    return p


def titulo_secao(doc, texto, nivel=1):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    pf = p.paragraph_format
    pf.line_spacing = 1.5
    pf.space_before = Pt(12)
    pf.space_after = Pt(6)
    pf.keep_with_next = True
    run = p.add_run(texto)
    run.font.name = "Times New Roman"
    run.font.size = Pt(12)
    run.font.color.rgb = PRETO
    run.bold = True
    if nivel == 1:
        run.font.all_caps = False  # ABNT: seção primária em CAIXA ALTA (texto já enviado em caixa alta)
    return p


def inserir_figura(doc, arquivo, numero, legenda, largura_cm=14):
    """Legenda (Figura N – ...) acima da imagem; 'Fonte:' abaixo, espaçamento simples."""
    caminho = os.path.join(ASSETS_DIR, arquivo)
    if not os.path.isfile(caminho):
        print(f"[AVISO] Figura não encontrada: {caminho} — inserindo apenas a legenda.")
        paragrafo(doc, f"[Inserir {arquivo} na pasta assets]", alinhamento=WD_ALIGN_PARAGRAPH.CENTER, espacamento=1)
    else:
        doc.add_picture(caminho, width=Cm(largura_cm))
        doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER

    # Legenda acima da figura (ABNT NBR 14724)
    paragrafo(doc, f"Figura {numero} – {legenda}",
              alinhamento=WD_ALIGN_PARAGRAPH.CENTER, espacamento=1.0, depois=4)
    paragrafo(doc, "Fonte: registros do projeto (2026).",
              alinhamento=WD_ALIGN_PARAGRAPH.CENTER, espacamento=1.0, antes=4, depois=12)


def tabela_grupos(doc):
    """Tabela simples de grupos (ABNT: bordas horizontais apenas)."""
    linhas = [
        ("Grupo", "Finalidade registrada no projeto"),
        ("ADM (teste)", "Grupo de teste registrado no ambiente."),
        ("Grupo 03 – Inventário e Patrimônio", "Atualização e controle dos ativos e da infraestrutura."),
        ("Grupo 01 – Estrutura e Governança", "Organização da estrutura e gestão de regras gerais."),
        ("Grupo 04 – Central de Atendimento", "Triagem, abertura e atribuição de chamados."),
        ("Grupo 05 – Prazos e Comunicação", "Acompanhamento de SLAs, indicadores e notificações."),
        ("Grupo 06 – Qualidade e Operação", "Auditoria, consulta e extração de dados operacionais."),
    ]
    tabela = doc.add_table(rows=len(linhas), cols=2)
    tabela.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, (c1, c2) in enumerate(linhas):
        for j, texto in enumerate((c1, c2)):
            celula = tabela.cell(i, j)
            celula.text = ""
            p = celula.paragraphs[0]
            p.paragraph_format.line_spacing = 1.0
            run = p.add_run(texto)
            run.font.name = "Times New Roman"
            run.font.size = Pt(11)
            run.font.color.rgb = PRETO
            run.bold = (i == 0)
    # bordas horizontais
    tbl = tabela._tbl
    for tc_pr in tbl.iter(qn("w:tcPr")):
        borders = OxmlElement("w:tcBorders")
        for borda in ("top", "bottom"):
            el = OxmlElement(f"w:{borda}")
            el.set(qn("w:val"), "single")
            el.set(qn("w:sz"), "4")
            el.set(qn("w:color"), "000000")
            borders.append(el)
        tc_pr.append(borders)

    paragrafo(doc, "Quadro 1 – Grupos de trabalho cadastrados no GLPI",
              alinhamento=WD_ALIGN_PARAGRAPH.CENTER, espacamento=1.0, antes=6, depois=4)
    paragrafo(doc, "Fonte: registros do projeto (2026).",
              alinhamento=WD_ALIGN_PARAGRAPH.CENTER, espacamento=1.0, depois=12)


# ---------------------------------------------------------------- documento
doc = Document()
configurar_pagina(doc)
definir_estilos(doc)

# ---- Folha de rosto
paragrafo(doc, "FACULDADE DE TECNOLOGIA PADRE DANILO DE OLIVEIRA OHL",
          alinhamento=WD_ALIGN_PARAGRAPH.CENTER, negrito=True, depois=24)
for autor in ("GEOVANA LOPES DE SOUSA", "HELOISA SANTOS MATOS",
              "HENRIQUE MOURA SILVA", "IAN BITENCURT DA CONCEIÇÃO"):
    paragrafo(doc, autor, alinhamento=WD_ALIGN_PARAGRAPH.CENTER, depois=0)

paragrafo(doc, "", depois=36)
paragrafo(doc, "INVENTÁRIO E PATRIMÔNIO",
          alinhamento=WD_ALIGN_PARAGRAPH.CENTER, negrito=True, depois=48)
paragrafo(
    doc,
    "Documentação técnica das atividades de organização e configuração do "
    "inventário e do patrimônio realizadas no sistema GLPI 11, na disciplina "
    "de Gestão da Tecnologia da Informação da Faculdade de Tecnologia de Barueri.",
    alinhamento=WD_ALIGN_PARAGRAPH.CENTER, depois=36)
paragrafo(doc, "Orientador: Prof. Vander Ribeiro Elme.", alinhamento=WD_ALIGN_PARAGRAPH.CENTER)
paragrafo(doc, "", depois=48)
paragrafo(doc, "BARUERI", alinhamento=WD_ALIGN_PARAGRAPH.CENTER, depois=0)
paragrafo(doc, "2026", alinhamento=WD_ALIGN_PARAGRAPH.CENTER)
doc.add_page_break()

# ---- Sumário
titulo_secao(doc, "SUMÁRIO")
for item in ("1 INTRODUÇÃO", "2 OBJETIVO", "3 INVENTÁRIO E GESTÃO PATRIMONIAL",
             "4 ORGANIZAÇÃO DOS GRUPOS DE TRABALHO",
             "5 CONFIGURAÇÃO DO INVENTÁRIO NO GLPI 11",
             "5.1 Perfil de Inventário e Patrimônio (Grupo 03)",
             "5.2 Apontamento e campo patrimonial",
             "5.3 Modelos, tipos e fabricantes",
             "5.4 Alocação de ativos aos usuários",
             "5.5 Estoque, centros de custo e contratos",
             "6 ETAPAS DE EXECUÇÃO NO GLPI 11",
             "7 CONSIDERAÇÕES FINAIS"):
    paragrafo(doc, item, alinhamento=WD_ALIGN_PARAGRAPH.LEFT, espacamento=1.5, depois=6)
doc.add_page_break()

# ---- 1 Introdução
titulo_secao(doc, "1 INTRODUÇÃO")
paragrafo(doc,
    "O GLPI 11 é utilizado no projeto como ferramenta para organizar a base de "
    "ativos de TI, o controle patrimonial e as responsabilidades sobre a "
    "infraestrutura. A configuração proposta busca garantir que cada item do "
    "patrimônio esteja cadastrado, localizado e vinculado corretamente, de modo "
    "a sustentar decisões de manutenção, renovação e auditoria. Além do "
    "levantamento dos ativos, foram definidos controles para reduzir o risco de "
    "exclusões indevidas e manter a confiabilidade das informações. Este "
    "documento apresenta os critérios adotados, a estrutura dos grupos e as "
    "configurações registradas durante a execução do projeto.", recuo_primeira=1.25)

# ---- 2 Objetivo
titulo_secao(doc, "2 OBJETIVO")
paragrafo(doc,
    "Estruturar o módulo de Inventário e Patrimônio no GLPI 11, cadastrando e "
    "classificando os ativos da organização, vinculando-os a usuários, locais e "
    "grupos responsáveis, e aplicando controles de permissão que limitem "
    "privilégios e protejam as informações patrimoniais administradas pelo "
    "sistema.", recuo_primeira=1.25)

# ---- 3 Inventário e gestão patrimonial
titulo_secao(doc, "3 INVENTÁRIO E GESTÃO PATRIMONIAL")
titulo_secao(doc, "3.1 Fundamentos do inventário", nivel=2)
paragrafo(doc,
    "O inventário constitui a base de conhecimento da infraestrutura de TI. "
    "No projeto, cada ativo foi descrito por tipo, modelo, fabricante, número "
    "serial, estado e localização, permitindo rastreabilidade ao longo do ciclo "
    "de vida do equipamento.", recuo_primeira=1.25)
titulo_secao(doc, "3.2 Controle patrimonial", nivel=2)
paragrafo(doc,
    "O campo de apontamento patrimonial foi utilizado para registrar o vínculo "
    "entre os bens físicos e os registros do sistema, facilitando conferências "
    "e auditorias futuras.", recuo_primeira=1.25)
titulo_secao(doc, "3.3 Segurança dos dados patrimoniais", nivel=2)
paragrafo(doc,
    "Em conformidade com as políticas do projeto, o perfil de inventário "
    "recebeu permissões de leitura, criação e atualização, com restrições "
    "rigorosas para exclusão, evitando a perda acidental de registros "
    "patrimoniais.", recuo_primeira=1.25)

# ---- 4 Grupos
titulo_secao(doc, "4 ORGANIZAÇÃO DOS GRUPOS DE TRABALHO")
paragrafo(doc,
    "A estrutura de grupos foi organizada para representar as áreas e "
    "responsabilidades previstas no projeto. O cadastro é realizado no caminho "
    "Administração > Grupos > Adicionar do GLPI 11.", recuo_primeira=1.25)
tabela_grupos(doc)
inserir_figura(doc, "figura1.png", 1,
               "Cadastro e organização dos grupos no GLPI 11")

# ---- 5 Configuração do inventário
titulo_secao(doc, "5 CONFIGURAÇÃO DO INVENTÁRIO NO GLPI 11")

titulo_secao(doc, "5.1 Perfil de Inventário e Patrimônio (Grupo 03)", nivel=2)
paragrafo(doc,
    "O perfil de Inventário foi configurado em Administração > Perfis > "
    "Inventário. A configuração tem como foco permitir a atualização contínua "
    "da base de ativos e da infraestrutura, sem expor o ambiente ao risco de "
    "exclusões acidentais de patrimônio. Foram previstas permissões de "
    "leitura, criação e atualização, com restrições rigorosas para exclusão.",
    recuo_primeira=1.25)
inserir_figura(doc, "figura2.png", 2,
               "Configuração do perfil de Inventário e Patrimônio")

titulo_secao(doc, "5.2 Apontamento e campo patrimonial", nivel=2)
paragrafo(doc,
    "O campo de apontamento patrimonial (Assets/Financial) foi habilitado nos "
    "tipos de ativos, permitindo associar o número patrimônio físico da "
    "organização a cada item cadastrado, base para as conferências periódicas.",
    recuo_primeira=1.25)
inserir_figura(doc, "figura3.png", 3,
               "Habilitação do apontamento patrimonial nos tipos de ativos")

titulo_secao(doc, "5.3 Modelos, tipos e fabricantes", nivel=2)
paragrafo(doc,
    "Foram cadastrados em Configuração > Suspensões/Taxonomia os modelos, "
    "tipos e fabricantes utilizados pela organização, padronizando o cadastro "
    "dos computadores, monitores, impressoras e dispositivos de rede.",
    recuo_primeira=1.25)
inserir_figura(doc, "figura4.png", 4,
               "Cadastro de modelos, tipos e fabricantes")

titulo_secao(doc, "5.4 Alocação de ativos aos usuários", nivel=2)
paragrafo(doc,
    "Cada ativo foi vinculado ao usuário responsável e ao local de instalação, "
    "por meio dos campos 'Usuário' e 'Local' da ficha do item, permitindo "
    "consultar rapidamente quem utiliza determinado equipamento e onde ele "
    "está instalado.", recuo_primeira=1.25)
inserir_figura(doc, "figura5.png", 5,
               "Vínculo de ativos a usuários e locais")

titulo_secao(doc, "5.5 Estoque, centros de custo e contratos", nivel=2)
paragrafo(doc,
    "Materiais de consumo e equipamentos em estoque foram registrados no "
    "Gerenciamento > Estoque, e as relações com centros de custo e contratos "
    "de garantia foram associadas à aba financeira dos ativos, consolidando a "
    "visão patrimonial do parque de TI.", recuo_primeira=1.25)
inserir_figura(doc, "figura6.png", 6,
               "Estoque, centros de custo e vínculos contratuais")

# ---- 6 Etapas
titulo_secao(doc, "6 ETAPAS DE EXECUÇÃO NO GLPI 11")
etapas = [
    ("Etapa 1 – Levantamento e análise de requisitos",
     "Identificação dos ativos existentes, definição dos tipos, modelos e "
     "locais, e escolha dos perfis adequados a cada função."),
    ("Etapa 2 – Configuração de segurança",
     "Ajuste da política de senhas em Configurar > Geral > Segurança e "
     "restrição do perfil de inventário contra exclusões de ativos."),
    ("Etapa 3 – Cadastro e organização dos grupos",
     "Criação do Grupo 03 – Inventário e Patrimônio em Administração > "
     "Grupos > Adicionar, conforme as áreas funcionais do projeto."),
    ("Etapa 4 – Criação de modelos e fabricantes",
     "Padronização do catálogo de modelos, tipos e fabricantes usados no "
     "cadastro de ativos."),
    ("Etapa 5 – Cadastramento dos ativos",
     "Registro dos computadores, monitores, impressoras e dispositivos de "
     "rede, com serial, patrimônio, local e usuário associado."),
    ("Etapas 6 e 7 – Alocação, estoque e conferências",
     "Vínculo dos ativos aos usuários e locais, registro do estoque e "
     "conferência dos vínculos financeiros e contratuais."),
]
for titulo, corpo in etapas:
    paragrafo(doc, titulo, negrito=True, depois=0)
    paragrafo(doc, corpo, recuo_primeira=1.25, depois=6)

# ---- 7 Conclusão
titulo_secao(doc, "7 CONSIDERAÇÕES FINAIS")
paragrafo(doc,
    "A configuração do Inventário e do Patrimônio no GLPI 11 estabelece uma "
    "base única e confiável de ativos, vinculada a usuários, locais e grupos "
    "responsáveis. A combinação de cadastro padronizado, campo patrimonial e "
    "permissões restritivas sobre exclusões contribui para a integridade das "
    "informações e para a redução do risco de alterações indevidas. Dessa "
    "forma, o projeto reúne controles que apoiam a gestão, a auditoria e a "
    "segurança do ambiente GLPI.", recuo_primeira=1.25)

saida = os.path.join(BASE_DIR, "Inventario_e_Patrimonio_ABNT.docx")
doc.save(saida)
print(f"Documento gerado: {saida}")